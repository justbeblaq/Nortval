import React, { createContext, useContext, useState, useEffect } from 'react';
import { BANK_CONFIG, SUPPORTED_CURRENCIES, CurrencyConfig } from '../config/bankConfig';
import { UserProfile, Transaction, BankCard, TransferPayload } from '../types/bank';

interface LoginResult {
  success: boolean;
  errorType?: 'WRONG_USERNAME' | 'WRONG_PASSWORD' | 'WRONG_PIN' | null;
  message?: string;
  field?: 'username' | 'password' | 'pin';
}

interface TransferResult {
  success: boolean;
  errorCode?: 'ACCOUNT_FROZEN' | 'INVALID_BENEFICIARY' | 'INSUFFICIENT_FUNDS' | 'INVALID_AMOUNT';
  error?: string;
  transaction?: Transaction;
}

interface ServiceUnavailableContext {
  title: string;
  service: string;
  description: string;
}

interface BankContextType {
  // Auth
  isAuthenticated: boolean;
  login: (username: string, password: string, pin: string) => LoginResult;
  logout: () => void;

  // Profile
  user: UserProfile;
  updateProfile: (updated: Partial<UserProfile>) => void;

  // Balances & Currency
  balance: number;
  savingsBalance: number;
  currency: string;
  currencyConfig: CurrencyConfig;
  setCurrency: (code: string) => void;
  setAccountBalance: (newBalance: number) => void;
  formatAmount: (amountInUSD: number, targetCurrencyCode?: string) => string;

  // Account Status
  isFrozen: boolean;
  toggleAccountFreeze: (forcedStatus?: boolean) => void;

  // Transactions & Transfers
  transactions: Transaction[];
  cards: BankCard[];
  toggleCardFreeze: (cardId: string) => void;
  executeTransfer: (payload: TransferPayload) => TransferResult;

  // Modals & Customer Service Routing
  supportModalOpen: boolean;
  supportContext: { reason?: string; prefillMessage?: string } | null;
  openCustomerService: (reason?: string, prefillMessage?: string) => void;
  closeCustomerService: () => void;

  loanModalOpen: boolean;
  openLoanModal: () => void;
  closeLoanModal: () => void;

  serviceUnavailableContext: ServiceUnavailableContext | null;
  openServiceUnavailableModal: (title: string, service: string, description: string) => void;
  closeServiceUnavailableModal: () => void;

  resetToDefaultConfig: () => void;
}

const BankContext = createContext<BankContextType | undefined>(undefined);

const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-001',
    referenceNumber: 'NRTV-982104-FED',
    date: 'Today, 10:14 AM',
    timestamp: Date.now() - 3600000 * 2,
    type: 'deposit',
    description: 'Direct Deposit - Global Wealth Management Yield',
    amount: 14250.00,
    currency: 'USD',
    status: 'completed',
    category: 'Direct Deposit',
    note: 'Quarterly dividends distribution',
  },
  {
    id: 'tx-002',
    referenceNumber: 'NRTV-881290-WRE',
    date: 'Yesterday, 03:42 PM',
    timestamp: Date.now() - 3600000 * 24,
    type: 'transfer_in',
    description: 'Incoming Fedwire from Morgan Stanley Private Wealth',
    recipientName: 'Harriet Vance',
    amount: 35000.00,
    currency: 'USD',
    status: 'completed',
    category: 'Wire Transfer',
    note: 'Ref: Portfolio rebalance settlement',
  },
  {
    id: 'tx-003',
    referenceNumber: 'NRTV-773192-FEE',
    date: 'May 12, 2026',
    timestamp: Date.now() - 3600000 * 48,
    type: 'fee',
    description: 'Nortval Private Client Concierge Custody Fee',
    amount: -150.00,
    currency: 'USD',
    status: 'completed',
    category: 'Service Fee',
    note: 'Monthly premier maintenance waived 50%',
  },
  {
    id: 'tx-004',
    referenceNumber: 'NRTV-612984-INT',
    date: 'May 01, 2026',
    timestamp: Date.now() - 3600000 * 120,
    type: 'interest',
    description: 'High-Yield Treasury Interest Credit',
    amount: 890.50,
    currency: 'USD',
    status: 'completed',
    category: 'Account Funding',
    note: 'Annualized 4.85% APY payout',
  }
];

const INITIAL_CARDS: BankCard[] = [
  {
    id: 'card-1',
    cardNumber: '4819 •••• •••• 9201',
    cardHolder: 'HARRIET VANCE',
    expiryDate: '09/29',
    cvv: '812',
    type: 'Visa Infinite Debit',
    isFrozen: false,
    spendingLimit: 25000,
    dailyWithdrawalLimit: 5000,
    color: 'from-slate-900 via-slate-800 to-emerald-950',
  },
  {
    id: 'card-2',
    cardNumber: '5420 •••• •••• 1184',
    cardHolder: 'HARRIET VANCE',
    expiryDate: '12/30',
    cvv: '449',
    type: 'Mastercard World Elite',
    isFrozen: false,
    spendingLimit: 50000,
    dailyWithdrawalLimit: 10000,
    color: 'from-zinc-900 via-amber-950/70 to-slate-900',
  }
];

export const BankProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Auth state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('nortval_auth') === 'true';
  });

  // User profile
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('nortval_user');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return {
      username: BANK_CONFIG.auth.username,
      name: BANK_CONFIG.account.accountHolderName,
      email: BANK_CONFIG.account.email,
      avatarUrl: BANK_CONFIG.account.avatarUrl,
      phone: BANK_CONFIG.account.phone,
    };
  });

  // Balances
  const [balance, setBalance] = useState<number>(() => {
    const saved = localStorage.getItem('nortval_balance');
    if (saved) {
      const parsed = parseFloat(saved);
      if (!isNaN(parsed)) return parsed;
    }
    return BANK_CONFIG.account.initialBalance;
  });

  const [savingsBalance, setSavingsBalance] = useState<number>(() => {
    const saved = localStorage.getItem('nortval_savings_balance');
    if (saved) {
      const parsed = parseFloat(saved);
      if (!isNaN(parsed)) return parsed;
    }
    return BANK_CONFIG.account.initialSavingsBalance;
  });

  // Currency
  const [currency, setCurrencyState] = useState<string>(() => {
    const saved = localStorage.getItem('nortval_currency');
    return saved || BANK_CONFIG.account.defaultCurrency;
  });

  // Account Frozen state
  const [isFrozen, setIsFrozen] = useState<boolean>(() => {
    const saved = localStorage.getItem('nortval_frozen');
    if (saved !== null) {
      return saved === 'true';
    }
    return BANK_CONFIG.account.isFrozen;
  });

  // Transactions
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('nortval_transactions');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return INITIAL_TRANSACTIONS;
  });

  // Cards
  const [cards, setCards] = useState<BankCard[]>(() => {
    const saved = localStorage.getItem('nortval_cards');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return INITIAL_CARDS;
  });

  // Modals
  const [supportModalOpen, setSupportModalOpen] = useState(false);
  const [supportContext, setSupportContext] = useState<{ reason?: string; prefillMessage?: string } | null>(null);
  const [loanModalOpen, setLoanModalOpen] = useState(false);
  const [serviceUnavailableContext, setServiceUnavailableContext] = useState<ServiceUnavailableContext | null>(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('nortval_auth', String(isAuthenticated));
  }, [isAuthenticated]);

  useEffect(() => {
    localStorage.setItem('nortval_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('nortval_balance', String(balance));
  }, [balance]);

  useEffect(() => {
    localStorage.setItem('nortval_savings_balance', String(savingsBalance));
  }, [savingsBalance]);

  useEffect(() => {
    localStorage.setItem('nortval_currency', currency);
  }, [currency]);

  useEffect(() => {
    localStorage.setItem('nortval_frozen', String(isFrozen));
  }, [isFrozen]);

  useEffect(() => {
    localStorage.setItem('nortval_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('nortval_cards', JSON.stringify(cards));
  }, [cards]);

  const currencyConfig = SUPPORTED_CURRENCIES[currency] || SUPPORTED_CURRENCIES.USD;

  // Format amount with currency conversion
  const formatAmount = (amountInUSD: number, targetCurrencyCode?: string) => {
    const curr = targetCurrencyCode ? (SUPPORTED_CURRENCIES[targetCurrencyCode] || currencyConfig) : currencyConfig;
    const converted = amountInUSD * curr.rateAgainstUSD;
    return `${curr.symbol}${converted.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`;
  };

  // Login handler with distinct error reporting
  const login = (inputUsername: string, inputPassword: string, inputPin: string): LoginResult => {
    const trimmedUsername = inputUsername.trim();
    const expectedUsername = user.username.trim(); // or BANK_CONFIG.auth.username
    const expectedPassword = BANK_CONFIG.auth.password;
    const expectedPin = BANK_CONFIG.auth.pin;

    // 1. Check Username
    if (trimmedUsername.toLowerCase() !== expectedUsername.toLowerCase()) {
      return {
        success: false,
        errorType: 'WRONG_USERNAME',
        field: 'username',
        message: `Account not found for username "${inputUsername}". The account does not exist in the Nortval banking directory. Please verify your credentials or contact customer service for account recovery.`,
      };
    }

    // 2. Check Password
    if (inputPassword !== expectedPassword) {
      return {
        success: false,
        errorType: 'WRONG_PASSWORD',
        field: 'password',
        message: `Incorrect password provided for user "${inputUsername}". If you forgot your password or suspect unauthorized lock, please reach out to customer service.`,
      };
    }

    // 3. Check Security PIN
    if (inputPin.trim() !== expectedPin) {
      return {
        success: false,
        errorType: 'WRONG_PIN',
        field: 'pin',
        message: `Invalid 4-digit Security PIN verification code. Two-factor authentication failed. Contact Nortval customer support to reset your authorization PIN.`,
      };
    }

    // Success
    setIsAuthenticated(true);
    return {
      success: true,
      message: 'Access granted. Welcome to Nortval Private Banking.',
    };
  };

  const logout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('nortval_auth');
  };

  const updateProfile = (updated: Partial<UserProfile>) => {
    setUser((prev) => ({
      ...prev,
      ...updated,
    }));
  };

  const setCurrency = (code: string) => {
    if (SUPPORTED_CURRENCIES[code]) {
      setCurrencyState(code);
    }
  };

  const setAccountBalance = (newBalance: number) => {
    setBalance(Math.max(0, newBalance));
  };

  const toggleAccountFreeze = (forcedStatus?: boolean) => {
    setIsFrozen((prev) => (forcedStatus !== undefined ? forcedStatus : !prev));
  };

  const toggleCardFreeze = (cardId: string) => {
    setCards((prev) =>
      prev.map((card) =>
        card.id === cardId ? { ...card, isFrozen: !card.isFrozen } : card
      )
    );
  };

  // Transfer Execution with Authorized Beneficiary & Frozen checks
  const executeTransfer = (payload: TransferPayload): TransferResult => {
    // 1. Check if Account is Frozen
    if (isFrozen) {
      openCustomerService(
        'Account Frozen - Transfer Blocked',
        `Urgent Support Request: My account (${BANK_CONFIG.account.accountNumber}) is currently frozen and outbound transfers are blocked. Please assist in unfreezing my account.`
      );
      return {
        success: false,
        errorCode: 'ACCOUNT_FROZEN',
        error: `Transfer restricted: Your Nortval account is currently FROZEN. Outbound wires and debit transfers are suspended. Please contact customer service at ${BANK_CONFIG.customerServicePhone} for immediate assistance.`,
      };
    }

    // 2. Validate Amount
    if (payload.amount <= 0 || isNaN(payload.amount)) {
      return {
        success: false,
        errorCode: 'INVALID_AMOUNT',
        error: 'Please enter a valid positive transfer amount.',
      };
    }

    // 3. Validate Balance
    if (payload.amount > balance) {
      return {
        success: false,
        errorCode: 'INSUFFICIENT_FUNDS',
        error: `Insufficient funds. Your available balance is ${formatAmount(balance)}, but you attempted to transfer ${formatAmount(payload.amount)}.`,
      };
    }

    // 4. Validate Authorized Beneficiary (Only configured accounts are accepted)
    const cleanedRecipientAccount = payload.recipientAccount.replace(/[-\s]/g, '');
    const isAuthorized = BANK_CONFIG.additionalAllowedAccounts.some((allowed) => {
      const cleanedAllowed = allowed.accountNumber.replace(/[-\s]/g, '');
      return cleanedRecipientAccount === cleanedAllowed;
    });

    if (!isAuthorized) {
      openCustomerService(
        'Unauthorized Beneficiary Verification',
        `Support Inquiry: I attempted to transfer $${payload.amount.toLocaleString()} to unverified account ${payload.recipientAccount} (${payload.recipientBank} - ${payload.recipientName}). Please assist me in adding this beneficiary.`
      );
      return {
        success: false,
        errorCode: 'INVALID_BENEFICIARY',
        error: `Beneficiary Verification Failed: Account number "${payload.recipientAccount}" is not in your pre-authorized recipient registry. For your security, wire transfers can only be routed to pre-approved accounts. Contact customer service at ${BANK_CONFIG.customerServicePhone} to authorize this beneficiary.`,
      };
    }

    // 5. Deduct Balance and record transaction
    const newBalance = balance - payload.amount;
    setBalance(newBalance);

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      referenceNumber: `NRTV-${Math.floor(100000 + Math.random() * 900000)}-WRE`,
      date: 'Just now',
      timestamp: Date.now(),
      type: 'transfer_out',
      description: `Wire Transfer to ${payload.recipientName} (${payload.recipientBank})`,
      recipientName: payload.recipientName,
      recipientBank: payload.recipientBank,
      recipientAccount: payload.recipientAccount,
      amount: -payload.amount,
      currency: currency,
      status: 'completed',
      category: 'Wire Transfer',
      note: payload.note || 'Online Wire Transfer',
    };

    setTransactions((prev) => [newTx, ...prev]);

    return {
      success: true,
      transaction: newTx,
    };
  };

  // Customer Service Modal Trigger
  const openCustomerService = (reason?: string, prefillMessage?: string) => {
    setSupportContext({ reason, prefillMessage });
    setSupportModalOpen(true);
  };

  const closeCustomerService = () => {
    setSupportModalOpen(false);
    setSupportContext(null);
  };

  // Loans modal
  const openLoanModal = () => setLoanModalOpen(true);
  const closeLoanModal = () => setLoanModalOpen(false);

  // General service unavailable modal
  const openServiceUnavailableModal = (title: string, service: string, description: string) => {
    setServiceUnavailableContext({ title, service, description });
  };
  const closeServiceUnavailableModal = () => {
    setServiceUnavailableContext(null);
  };

  // Reset to default code configuration
  const resetToDefaultConfig = () => {
    setBalance(BANK_CONFIG.account.initialBalance);
    setSavingsBalance(BANK_CONFIG.account.initialSavingsBalance);
    setCurrencyState(BANK_CONFIG.account.defaultCurrency);
    setIsFrozen(BANK_CONFIG.account.isFrozen);
    setUser({
      username: BANK_CONFIG.auth.username,
      name: BANK_CONFIG.account.accountHolderName,
      email: BANK_CONFIG.account.email,
      avatarUrl: BANK_CONFIG.account.avatarUrl,
      phone: BANK_CONFIG.account.phone,
    });
    setTransactions(INITIAL_TRANSACTIONS);
    setCards(INITIAL_CARDS);
    localStorage.removeItem('nortval_user');
    localStorage.removeItem('nortval_balance');
    localStorage.removeItem('nortval_savings_balance');
    localStorage.removeItem('nortval_currency');
    localStorage.removeItem('nortval_frozen');
    localStorage.removeItem('nortval_transactions');
    localStorage.removeItem('nortval_cards');
  };

  return (
    <BankContext.Provider
      value={{
        isAuthenticated,
        login,
        logout,
        user,
        updateProfile,
        balance,
        savingsBalance,
        currency,
        currencyConfig,
        setCurrency,
        setAccountBalance,
        formatAmount,
        isFrozen,
        toggleAccountFreeze,
        transactions,
        cards,
        toggleCardFreeze,
        executeTransfer,
        supportModalOpen,
        supportContext,
        openCustomerService,
        closeCustomerService,
        loanModalOpen,
        openLoanModal,
        closeLoanModal,
        serviceUnavailableContext,
        openServiceUnavailableModal,
        closeServiceUnavailableModal,
        resetToDefaultConfig,
      }}
    >
      {children}
    </BankContext.Provider>
  );
};

export const useBank = (): BankContextType => {
  const context = useContext(BankContext);
  if (!context) {
    throw new Error('useBank must be used within a BankProvider');
  }
  return context;
};
