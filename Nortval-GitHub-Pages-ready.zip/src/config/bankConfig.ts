/**
 * ============================================================================
 * NORTVAL BANK & TRUST - CONFIGURATION FILE
 * ============================================================================
 * 
 * Edit the values below to customize credentials, account balance, 
 * supported currencies, authorized transfer recipients, and customer service.
 */

export interface CurrencyConfig {
  code: string;
  symbol: string;
  name: string;
  rateAgainstUSD: number; // 1 USD = rate
}

export const SUPPORTED_CURRENCIES: Record<string, CurrencyConfig> = {
  USD: { code: 'USD', symbol: '$', name: 'US Dollar ($)', rateAgainstUSD: 1.0 },
  EUR: { code: 'EUR', symbol: '€', name: 'Euro (€)', rateAgainstUSD: 0.92 },
  GBP: { code: 'GBP', symbol: '£', name: 'British Pound (£)', rateAgainstUSD: 0.79 },
  CAD: { code: 'CAD', symbol: 'CA$', name: 'Canadian Dollar (CA$)', rateAgainstUSD: 1.36 },
  CHF: { code: 'CHF', symbol: 'CHF', name: 'Swiss Franc (CHF)', rateAgainstUSD: 0.90 },
  JPY: { code: 'JPY', symbol: '¥', name: 'Japanese Yen (¥)', rateAgainstUSD: 155.0 },
  AUD: { code: 'AUD', symbol: 'A$', name: 'Australian Dollar (A$)', rateAgainstUSD: 1.52 },
};

export const BANK_CONFIG = {
  // --- BANK IDENTITY ---
  bankName: "Nortval Bank & Trust",
  bankShortName: "Nortval",
  bankRoutingNumber: "071101928",
  swiftCode: "NRTVUS33XXX",
  establishedYear: "1894",
  fdicCertificate: "FDIC-491028-A",

  // --- CUSTOMER SERVICE & SMS SUPPORT ---
  customerServicePhone: "+1 (708) 628-7118",
  customerServiceRawPhone: "+17086287118",
  customerServiceEmail: "support@nortval.com",
  customerServiceHours: "24/7 Dedicated Support",

  // --- USER AUTHENTICATION CREDENTIALS ---
  // Modify these credentials to change the login requirements
  auth: {
    username: "harriet020",
    password: "Harr1et0921",
    pin: "0921",
  },

  // --- USER ACCOUNT INITIAL STATE ---
  account: {
    accountHolderName: "Harriet Vance",
    accountNumber: "4810-9281-7740",
    accountType: "Nortval Premier Private Banking",
    email: "harriet.vance@nortval-client.com",
    avatarUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80",
    phone: "+1 (555) 234-8901",
    
    // Initial balance in USD (edit here to change default balance)
    initialBalance: 50000.00,
    
    // Initial savings balance
    initialSavingsBalance: 125000.00,

    // Initial Currency (e.g. 'USD', 'EUR', 'GBP', 'CAD', 'CHF', 'JPY', 'AUD')
    defaultCurrency: "USD" as keyof typeof SUPPORTED_CURRENCIES,

    // Initial Freeze State: true = frozen (cannot transfer), false = active
    isFrozen: false,
  },

  // --- AUTHORIZED TRANSFER RECIPIENT ---
  // Money can ONLY be transferred to this specific configured recipient.
  // Any other recipient will be flagged and redirected to customer service.
  authorizedRecipient: {
    accountNumber: "9823471029",
    accountName: "Harriet Vance",
    bankName: "JPMorgan Chase Bank",
    routingNumber: "021000021",
    accountType: "Checking",
  },

  // Alternative allowed accounts if you wish to expand
  additionalAllowedAccounts: [
    {
      accountNumber: "9823471029",
      accountName: "Harriet Vance",
      bankName: "JPMorgan Chase Bank",
      routingNumber: "021000021",
      accountType: "Checking",
    },
    {
      accountNumber: "481092817740",
      accountName: "Harriet Vance",
      bankName: "Nortval Bank & Trust",
      routingNumber: "071101928",
      accountType: "Savings Reserve",
    }
  ]
};
