import React, { useState } from 'react';
import { 
  User, Mail, Phone, Lock, Unlock, Check, 
  Globe, Code2, RefreshCw, Image, Shield
} from 'lucide-react';
import { useBank } from '../context/BankContext';
import { SUPPORTED_CURRENCIES } from '../config/bankConfig';

const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80',
];

interface SettingsPageProps {
  onOpenConfigModal: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ onOpenConfigModal }) => {
  const { 
    user, 
    updateProfile, 
    balance, 
    setAccountBalance, 
    isFrozen, 
    toggleAccountFreeze, 
    currency, 
    setCurrency, 
    resetToDefaultConfig 
  } = useBank();

  // Profile Form State
  const [name, setName] = useState(user.name);
  const [username, setUsername] = useState(user.username);
  const [email, setEmail] = useState(user.email);
  const [phone, setPhone] = useState(user.phone);
  const [avatarUrl, setAvatarUrl] = useState(user.avatarUrl);
  const [customAvatarInput, setCustomAvatarInput] = useState('');
  const [profileSaved, setProfileSaved] = useState(false);

  // Balance Form State
  const [balanceInput, setBalanceInput] = useState(String(balance));
  const [balanceSaved, setBalanceSaved] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name: name.trim(),
      username: username.trim(),
      email: email.trim(),
      phone: phone.trim(),
      avatarUrl: avatarUrl.trim(),
    });
    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 3000);
  };

  const handleSaveBalance = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(balanceInput);
    if (!isNaN(val) && val >= 0) {
      setAccountBalance(val);
      setBalanceSaved(true);
      setTimeout(() => setBalanceSaved(false), 3000);
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-2xl">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white font-serif">
            Client Profile & Account Settings
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Update your personal profile, credentials, display currency, and balance parameters.
          </p>
        </div>

        <button
          onClick={onOpenConfigModal}
          className="flex items-center gap-1.5 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 px-3.5 py-2 rounded-xl text-xs font-medium transition-colors"
        >
          <Code2 className="w-4 h-4 text-indigo-400" />
          <span>Edit via Code Config Guide</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Profile Management Form */}
        <div className="lg:col-span-2 space-y-6">
          <form
            onSubmit={handleSaveProfile}
            className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-bold text-white font-serif">
                  Personal Client Profile
                </h3>
                <p className="text-xs text-slate-400">
                  Edit your name, username, email, and photo
                </p>
              </div>
              <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">
                Verified Identity
              </span>
            </div>

            {/* Profile Picture Selector */}
            <div className="space-y-3">
              <label className="block text-xs font-semibold text-slate-300">
                Profile Avatar
              </label>
              <div className="flex flex-wrap items-center gap-4">
                <img
                  src={avatarUrl}
                  alt={name}
                  className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-500/50 shadow-md"
                />

                <div className="space-y-2 flex-1">
                  <div className="text-[11px] text-slate-400">Select preset avatar:</div>
                  <div className="flex items-center gap-2 overflow-x-auto pb-1">
                    {AVATAR_PRESETS.map((preset, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setAvatarUrl(preset)}
                        className={`w-9 h-9 rounded-xl overflow-hidden border-2 transition-all ${
                          avatarUrl === preset ? 'border-emerald-400 scale-105 shadow-md' : 'border-slate-700 opacity-60 hover:opacity-100'
                        }`}
                      >
                        <img src={preset} alt="preset" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Custom Image URL input */}
              <div className="pt-1">
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Image className="w-4 h-4 text-slate-500 absolute left-3 top-2.5 pointer-events-none" />
                    <input
                      type="url"
                      placeholder="Or paste custom image URL..."
                      value={customAvatarInput}
                      onChange={(e) => setCustomAvatarInput(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      if (customAvatarInput.trim()) {
                        setAvatarUrl(customAvatarInput.trim());
                        setCustomAvatarInput('');
                      }
                    }}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-2 rounded-xl text-xs font-medium border border-slate-700"
                  >
                    Apply URL
                  </button>
                </div>
              </div>
            </div>

            {/* Profile Fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Full Name
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Username (Login ID)
                </label>
                <div className="relative">
                  <span className="text-slate-500 font-bold absolute left-3.5 top-2 text-xs">@</span>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Registered Phone
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            </div>

            {/* Save Profile Button */}
            <div className="flex items-center justify-between pt-2">
              {profileSaved && (
                <span className="text-xs text-emerald-400 flex items-center gap-1 font-semibold animate-in fade-in">
                  <Check className="w-4 h-4" />
                  Profile updated successfully!
                </span>
              )}
              <div className="ml-auto">
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold px-5 py-2.5 rounded-xl text-xs shadow-lg shadow-emerald-950 transition-colors"
                >
                  Save Profile Changes
                </button>
              </div>
            </div>
          </form>

          {/* Account Balance Management */}
          <form
            onSubmit={handleSaveBalance}
            className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4"
          >
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white font-serif">
                Account Balance Controller
              </h3>
              <p className="text-xs text-slate-400">
                Quickly customize available checking balance (default: $50,000.00). Also editable in <code className="text-indigo-300 font-mono">src/config/bankConfig.ts</code>.
              </p>
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-medium text-slate-300">
                Primary Checking Balance (USD)
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <span className="absolute left-3.5 top-2.5 text-slate-500 font-bold text-xs">$</span>
                  <input
                    type="number"
                    step="any"
                    value={balanceInput}
                    onChange={(e) => setBalanceInput(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3.5 py-2.5 text-xs font-mono font-bold text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold px-4 py-2.5 rounded-xl text-xs transition-colors shadow-md"
                >
                  Update Balance
                </button>
              </div>

              {/* Quick Presets */}
              <div className="flex gap-2 pt-1">
                {[25000, 50000, 100000, 250000].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => {
                      setBalanceInput(String(preset));
                      setAccountBalance(preset);
                      setBalanceSaved(true);
                      setTimeout(() => setBalanceSaved(false), 2500);
                    }}
                    className="flex-1 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-[11px] font-mono text-slate-300 transition-colors"
                  >
                    ${preset.toLocaleString()}
                  </button>
                ))}
              </div>

              {balanceSaved && (
                <div className="text-xs text-emerald-400 font-medium flex items-center gap-1 pt-1">
                  <Check className="w-3.5 h-3.5" />
                  <span>Balance updated to ${parseFloat(balanceInput).toLocaleString()}</span>
                </div>
              )}
            </div>
          </form>
        </div>

        {/* Right Col: Currency, Freeze Switch, and Reset */}
        <div className="space-y-6">
          {/* Currency Switcher */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center gap-2">
              <Globe className="w-5 h-5 text-emerald-400" />
              <div>
                <h3 className="text-sm font-bold text-white">
                  Display Currency
                </h3>
                <p className="text-[11px] text-slate-400">
                  Switch bank reporting currency
                </p>
              </div>
            </div>

            <div className="space-y-2">
              {Object.values(SUPPORTED_CURRENCIES).map((c) => (
                <button
                  key={c.code}
                  type="button"
                  onClick={() => setCurrency(c.code)}
                  className={`w-full p-2.5 rounded-xl border text-xs flex items-center justify-between transition-all ${
                    currency === c.code
                      ? 'bg-emerald-950/40 border-emerald-500 text-white font-semibold'
                      : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-emerald-400 font-bold">{c.symbol}</span>
                    <span>{c.name}</span>
                  </div>
                  {currency === c.code && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                </button>
              ))}
            </div>
          </div>

          {/* Account Freeze Status Toggle */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-amber-400" />
              <div>
                <h3 className="text-sm font-bold text-white">
                  Account Freeze Security
                </h3>
                <p className="text-[11px] text-slate-400">
                  Prevent all outbound transfers
                </p>
              </div>
            </div>

            <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800 text-xs space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Status:</span>
                <span className={`font-bold ${isFrozen ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {isFrozen ? 'FROZEN (Locked)' : 'ACTIVE (Unlocked)'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                {isFrozen
                  ? 'Transfers are blocked and will redirect to customer service.'
                  : 'Outbound wires and debits are enabled.'}
              </p>
            </div>

            <button
              type="button"
              onClick={() => toggleAccountFreeze()}
              className={`w-full py-2.5 px-4 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                isFrozen
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white border-transparent'
                  : 'bg-amber-600 hover:bg-amber-500 text-slate-950 border-transparent'
              }`}
            >
              {isFrozen ? (
                <>
                  <Unlock className="w-4 h-4" />
                  <span>Unfreeze Account Now</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Freeze Account Now</span>
                </>
              )}
            </button>
          </div>

          {/* Reset Defaults */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              System Reset
            </h3>
            <p className="text-[11px] text-slate-400">
              Clear local storage overrides and restore default code configuration from <code className="text-indigo-300 font-mono">bankConfig.ts</code>.
            </p>
            <button
              type="button"
              onClick={resetToDefaultConfig}
              className="w-full py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-xl text-xs font-medium transition-colors flex items-center justify-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
              <span>Reset All to Defaults</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
