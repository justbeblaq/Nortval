import React, { useState } from 'react';
import { BankProvider, useBank } from './context/BankContext';
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { TransactionsPage } from './pages/TransactionsPage';
import { CardsPage } from './pages/CardsPage';
import { SettingsPage } from './pages/SettingsPage';
import { Navbar } from './components/Navbar';
import { CustomerServiceModal } from './components/CustomerServiceModal';
import { CustomerServiceFloat } from './components/CustomerServiceFloat';
import { LoanModal } from './components/LoanModal';
import { GeneralServiceUnavailableModal } from './components/GeneralServiceUnavailableModal';
import { TransferModal } from './components/TransferModal';
import { TransactionReceiptModal } from './components/TransactionReceiptModal';
import { CodeConfigViewerModal } from './components/CodeConfigViewerModal';
import { Transaction } from './types/bank';
import { BANK_CONFIG } from './config/bankConfig';
import { Shield } from 'lucide-react';

const MainApp: React.FC = () => {
  const { isAuthenticated, openCustomerService } = useBank();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);
  const [selectedReceipt, setSelectedReceipt] = useState<Transaction | null>(null);

  const handleTransferSuccess = (tx: Transaction) => {
    setSelectedReceipt(tx);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {!isAuthenticated ? (
        <LoginPage onOpenConfigModal={() => setIsConfigModalOpen(true)} />
      ) : (
        <>
          <Navbar
            activeTab={activeTab}
            onNavigate={setActiveTab}
            onOpenTransferModal={() => setIsTransferModalOpen(true)}
            onOpenConfigModal={() => setIsConfigModalOpen(true)}
          />

          <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
            {activeTab === 'dashboard' && (
              <DashboardPage
                onOpenTransferModal={() => setIsTransferModalOpen(true)}
                onOpenConfigModal={() => setIsConfigModalOpen(true)}
                onSelectTransaction={(tx) => setSelectedReceipt(tx)}
                onNavigate={setActiveTab}
              />
            )}
            {activeTab === 'transactions' && (
              <TransactionsPage
                onSelectTransaction={(tx) => setSelectedReceipt(tx)}
                onOpenTransferModal={() => setIsTransferModalOpen(true)}
              />
            )}
            {activeTab === 'cards' && <CardsPage />}
            {activeTab === 'settings' && (
              <SettingsPage onOpenConfigModal={() => setIsConfigModalOpen(true)} />
            )}
          </main>

          {/* Internal Footer */}
          <footer className="bg-slate-900 border-t border-slate-800 text-xs text-slate-400 py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                <span>
                  © {new Date().getFullYear()} {BANK_CONFIG.bankName}. All Rights Reserved. Member FDIC #{BANK_CONFIG.fdicCertificate}.
                </span>
              </div>
              <div className="flex items-center gap-4 text-[11px]">
                <button
                  onClick={() => setIsConfigModalOpen(true)}
                  className="hover:text-indigo-300 transition-colors"
                >
                  Code Config (bankConfig.ts)
                </button>
                <span>•</span>
                <button
                  onClick={() => openCustomerService('Footer Support Link')}
                  className="text-emerald-400 hover:text-emerald-300 font-medium"
                >
                  SMS Support: {BANK_CONFIG.customerServicePhone}
                </button>
              </div>
            </div>
          </footer>
        </>
      )}

      {/* Global Modals and Support Floats (Available both inside & outside as requested) */}
      <CustomerServiceModal />
      <CustomerServiceFloat />
      <LoanModal />
      <GeneralServiceUnavailableModal />
      <TransferModal
        isOpen={isTransferModalOpen}
        onClose={() => setIsTransferModalOpen(false)}
        onSuccess={handleTransferSuccess}
      />
      <TransactionReceiptModal
        transaction={selectedReceipt}
        onClose={() => setSelectedReceipt(null)}
      />
      <CodeConfigViewerModal
        isOpen={isConfigModalOpen}
        onClose={() => setIsConfigModalOpen(false)}
      />
    </div>
  );
};

export function App() {
  return (
    <BankProvider>
      <MainApp />
    </BankProvider>
  );
}

export default App;
