import React from 'react';
import { X, AlertCircle, MessageSquare, Phone, ArrowRight } from 'lucide-react';
import { useBank } from '../context/BankContext';
import { BANK_CONFIG } from '../config/bankConfig';

export const GeneralServiceUnavailableModal: React.FC = () => {
  const { 
    serviceUnavailableContext, 
    closeServiceUnavailableModal, 
    openCustomerService 
  } = useBank();

  if (!serviceUnavailableContext) return null;

  const handleMessageSupport = () => {
    const serviceName = serviceUnavailableContext.service;
    closeServiceUnavailableModal();
    openCustomerService(
      `Inquiry: ${serviceName}`,
      `Hello Nortval Support, I am inquiring about access to "${serviceName}". Please assist me with the manual verification or activation process.`
    );
  };

  const directSmsUrl = `sms:${BANK_CONFIG.customerServiceRawPhone}?body=${encodeURIComponent(
    `Hello Nortval Support, I would like more information regarding ${serviceUnavailableContext.service}.`
  )}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-blue-950/50 via-slate-900 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">
                {serviceUnavailableContext.title || 'Feature Unavailable'}
              </h3>
              <p className="text-xs text-slate-400">
                {serviceUnavailableContext.service}
              </p>
            </div>
          </div>
          <button
            onClick={closeServiceUnavailableModal}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4 text-slate-200">
          <div className="p-4 bg-slate-800/80 border border-slate-700 rounded-xl space-y-2 text-xs">
            <p className="font-semibold text-slate-100 text-sm">
              Service Routed to Private Concierge
            </p>
            <p className="text-slate-300 leading-relaxed">
              {serviceUnavailableContext.description || 
                'This feature is currently handled directly by your dedicated Nortval Private Banking specialist. Please contact customer service for activation or manual processing.'}
            </p>
          </div>

          {/* SMS Contact Callout */}
          <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-emerald-400" />
              <span className="text-slate-300">Dedicated Support SMS:</span>
            </div>
            <span className="font-mono font-bold text-emerald-400">
              {BANK_CONFIG.customerServicePhone}
            </span>
          </div>

          {/* Actions */}
          <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <button
              onClick={handleMessageSupport}
              className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-2.5 px-4 rounded-xl text-xs transition-colors shadow-lg shadow-emerald-950"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Contact Concierge Desk</span>
            </button>

            <a
              href={directSmsUrl}
              className="w-full flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium py-2.5 px-4 rounded-xl text-xs border border-slate-700 transition-colors"
            >
              <span>SMS ({BANK_CONFIG.customerServicePhone})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 text-center text-[11px] text-slate-500">
          Nortval Bank & Trust • Private Client Advisory
        </div>
      </div>
    </div>
  );
};
