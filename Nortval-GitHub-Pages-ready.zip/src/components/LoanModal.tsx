import React from 'react';
import { X, AlertCircle, MessageSquare, Phone, ShieldCheck, ArrowRight, Banknote } from 'lucide-react';
import { useBank } from '../context/BankContext';
import { BANK_CONFIG } from '../config/bankConfig';

export const LoanModal: React.FC = () => {
  const { loanModalOpen, closeLoanModal, openCustomerService } = useBank();

  if (!loanModalOpen) return null;

  const handleMessageSupport = () => {
    closeLoanModal();
    openCustomerService(
      'Private Lending Facility Inquiry',
      'Hello Nortval Lending Desk, I am inquiring about loan facilities and lines of credit for my account. Please provide current availability and eligibility criteria.'
    );
  };

  const directSmsUrl = `sms:${BANK_CONFIG.customerServiceRawPhone}?body=${encodeURIComponent(
    'Hello Nortval Support, I would like to inquire about loan options and line of credit features.'
  )}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-amber-950/50 via-slate-900 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Banknote className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">
                Nortval Private Credit & Lending
              </h3>
              <p className="text-xs text-slate-400">Service Status Notice</p>
            </div>
          </div>
          <button
            onClick={closeLoanModal}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4 text-slate-200">
          <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-1 text-xs">
              <p className="font-semibold text-amber-300 text-sm">
                Loan Features are Currently Unavailable
              </p>
              <p className="text-slate-300 leading-relaxed">
                Self-service online credit applications and personal loan facilities are currently undergoing portfolio maintenance and regulatory audit. Automated loan origination is paused.
              </p>
            </div>
          </div>

          <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-slate-300 font-medium">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Direct Underwriter Consultation</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              For commercial credit lines, customized collateralized loans, or mortgage structuring, please contact our dedicated Private Wealth Lending Officer via SMS or live support.
            </p>
          </div>

          {/* SMS Contact Callout */}
          <div className="p-3 bg-slate-800/60 border border-slate-700/80 rounded-xl flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-emerald-400" />
              <span className="text-slate-300">Dedicated SMS Hotline:</span>
            </div>
            <span className="font-mono font-bold text-emerald-400">
              {BANK_CONFIG.customerServicePhone}
            </span>
          </div>

          {/* Actions */}
          <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <button
              onClick={handleMessageSupport}
              className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-2.5 px-4 rounded-xl text-xs transition-colors shadow-lg shadow-emerald-950"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Message for More Information</span>
            </button>

            <a
              href={directSmsUrl}
              className="w-full flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium py-2.5 px-4 rounded-xl text-xs border border-slate-700 transition-colors"
            >
              <span>Direct SMS ({BANK_CONFIG.customerServicePhone})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 text-center text-[11px] text-slate-500">
          Nortval Bank & Trust • Equal Housing Lender • NMLS #481920
        </div>
      </div>
    </div>
  );
};
