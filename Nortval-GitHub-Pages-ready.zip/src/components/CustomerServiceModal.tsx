import React, { useState, useEffect, useRef } from 'react';
import { 
  X, MessageSquare, Phone, Send, Copy, Check, ShieldCheck, 
  ExternalLink, UserCheck, Clock, HelpCircle, AlertTriangle, Sparkles 
} from 'lucide-react';
import { useBank } from '../context/BankContext';
import { BANK_CONFIG } from '../config/bankConfig';

interface ChatMessage {
  id: string;
  sender: 'user' | 'agent' | 'system';
  text: string;
  time: string;
  isAction?: boolean;
}

export const CustomerServiceModal: React.FC = () => {
  const { supportModalOpen, closeCustomerService, supportContext, user } = useBank();
  const [copied, setCopied] = useState(false);
  const [inputMessage, setInputMessage] = useState('');
  const [activeTab, setActiveTab] = useState<'sms' | 'chat'>('sms');
  const [isTyping, setIsTyping] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'm1',
      sender: 'agent',
      text: `Welcome to Nortval Private Client Concierge. I am Marcus Reed, your dedicated Account Specialist. How may I assist you today?`,
      time: 'Just now',
    }
  ]);

  // When supportContext changes, update initial chat or prefill
  useEffect(() => {
    if (supportContext?.reason || supportContext?.prefillMessage) {
      const reasonText = supportContext.reason || 'Account Inquiry';
      const detailText = supportContext.prefillMessage || 'I need assistance regarding my Nortval account.';

      setMessages((prev) => [
        ...prev,
        {
          id: `m-${Date.now()}-sys`,
          sender: 'system',
          text: `[Context: ${reasonText}] - ${detailText}`,
          time: 'Just now',
        },
        {
          id: `m-${Date.now()}-agent`,
          sender: 'agent',
          text: `I noticed your request regarding "${reasonText}". Our security specialists are available 24/7 via direct SMS at ${BANK_CONFIG.customerServicePhone}. You can message us right below or dispatch an instant SMS.`,
          time: 'Just now',
        }
      ]);

      if (supportContext.prefillMessage) {
        setInputMessage(supportContext.prefillMessage);
      }
    }
  }, [supportContext]);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  if (!supportModalOpen) return null;

  const handleCopyPhone = () => {
    navigator.clipboard.writeText(BANK_CONFIG.customerServicePhone);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSendMessage = (textToSend?: string) => {
    const text = textToSend || inputMessage;
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text: text.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate smart bank agent response
    setTimeout(() => {
      setIsTyping(false);
      let replyText = `Thank you for your message, ${user.name || 'Valued Client'}. Your inquiry has been logged with Priority Security Ticket #${Math.floor(100000 + Math.random() * 900000)}. For real-time authorization and SMS verification, our senior officer is standing by at ${BANK_CONFIG.customerServicePhone}.`;

      const lower = text.toLowerCase();
      if (lower.includes('freeze') || lower.includes('frozen') || lower.includes('unfreeze')) {
        replyText = `Regarding account restriction status: To protect your assets, manual unfreeze requires security protocol validation. Please dispatch a brief SMS containing your authorization code to ${BANK_CONFIG.customerServicePhone} and our tier-3 officer will immediately review your request.`;
      } else if (lower.includes('loan') || lower.includes('credit') || lower.includes('borrow')) {
        replyText = `Nortval Private Wealth Loan facilities and line of credit expansions are currently undergoing quarterly portfolio review and self-service lending is unavailable. Please send an SMS to ${BANK_CONFIG.customerServicePhone} for custom credit structuring.`;
      } else if (lower.includes('transfer') || lower.includes('recipient') || lower.includes('beneficiary')) {
        replyText = `Wire Transfer Beneficiary Notice: Transacting to new or unverified beneficiaries requires telephone or SMS two-way authorization. Please confirm the recipient details via SMS to ${BANK_CONFIG.customerServicePhone}.`;
      } else if (lower.includes('password') || lower.includes('pin') || lower.includes('login') || lower.includes('username')) {
        replyText = `Account Credentials Recovery: For authentication security, credential reset tokens are transmitted directly via SMS. Send "RESET" to ${BANK_CONFIG.customerServicePhone} from your registered phone.`;
      }

      setMessages((prev) => [
        ...prev,
        {
          id: `a-${Date.now()}`,
          sender: 'agent',
          text: replyText,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        }
      ]);
    }, 1200);
  };

  const smsUrl = `sms:${BANK_CONFIG.customerServiceRawPhone}${supportContext?.prefillMessage ? `?body=${encodeURIComponent(supportContext.prefillMessage)}` : `?body=${encodeURIComponent(`Hello Nortval Support, I need assistance with my account for ${user.name || 'client'}.`)}`}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950/60 p-5 border-b border-slate-700/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400 shadow-inner">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-semibold text-white tracking-wide">
                  Nortval Private Client Concierge
                </h3>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  24/7 Live
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Official SMS Support & Secure Banking Assistance
              </p>
            </div>
          </div>
          <button
            onClick={closeCustomerService}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Support Alert Banner (if reason exists) */}
        {supportContext?.reason && (
          <div className="bg-amber-950/40 border-b border-amber-800/40 px-5 py-2.5 flex items-center gap-2 text-amber-200 text-xs">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="font-medium">Assistance Request:</span>
            <span className="truncate">{supportContext.reason}</span>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="bg-slate-950/60 border-b border-slate-800 px-5 flex gap-2 pt-2">
          <button
            onClick={() => setActiveTab('sms')}
            className={`pb-2.5 px-4 text-sm font-medium border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'sms'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Phone className="w-4 h-4" />
            Direct SMS Channel
          </button>
          <button
            onClick={() => setActiveTab('chat')}
            className={`pb-2.5 px-4 text-sm font-medium border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'chat'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            Live Client Portal Chat
          </button>
        </div>

        {/* Content Body */}
        {activeTab === 'sms' ? (
          <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-200">
            {/* Direct SMS Hero Card */}
            <div className="bg-gradient-to-br from-emerald-950/50 via-slate-800/80 to-slate-900 border border-emerald-500/30 rounded-xl p-5 relative overflow-hidden shadow-lg">
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="text-xs uppercase tracking-wider font-semibold text-emerald-400">
                    Official Support Phone Number
                  </div>
                  <div className="text-2xl sm:text-3xl font-mono font-bold text-white tracking-wider">
                    {BANK_CONFIG.customerServicePhone}
                  </div>
                  <p className="text-xs text-slate-300 pt-1">
                    Send an SMS for instant assistance with login recovery, account unfreeze, wire verification, and private banking inquiries.
                  </p>
                </div>
                <div className="p-3 bg-emerald-500/10 rounded-xl text-emerald-400 border border-emerald-500/20 shrink-0">
                  <Phone className="w-6 h-6" />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3">
                <a
                  href={smsUrl}
                  className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-3 px-4 rounded-xl shadow-lg shadow-emerald-900/40 transition-all hover:scale-[1.01] active:scale-[0.99] text-sm"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Send SMS Message Now</span>
                  <ExternalLink className="w-3.5 h-3.5 opacity-80" />
                </a>

                <button
                  onClick={handleCopyPhone}
                  className="w-full flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium py-3 px-4 rounded-xl border border-slate-700 transition-colors text-sm"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span className="text-emerald-400">Copied to Clipboard!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-slate-400" />
                      <span>Copy Number ({BANK_CONFIG.customerServicePhone})</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Quick Action Scenarios */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Quick Assistance Topics
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <button
                  onClick={() => {
                    setActiveTab('chat');
                    handleSendMessage('I need assistance unfreezing my Nortval bank account balance.');
                  }}
                  className="p-3 text-left rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-slate-600 transition-all flex items-start gap-2.5 group"
                >
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-medium text-slate-200 group-hover:text-emerald-400 transition-colors">
                      Account Frozen / Restricted
                    </div>
                    <div className="text-slate-400 text-[11px]">
                      Unlock debit & outbound wire permissions
                    </div>
                  </div>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('chat');
                    handleSendMessage('I want to authorize recipient Harriet Vance (Chase Bank #9823471029) or another beneficiary.');
                  }}
                  className="p-3 text-left rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-slate-600 transition-all flex items-start gap-2.5 group"
                >
                  <UserCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-medium text-slate-200 group-hover:text-emerald-400 transition-colors">
                      Authorize Transfer Beneficiary
                    </div>
                    <div className="text-slate-400 text-[11px]">
                      Verify and register new bank account
                    </div>
                  </div>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('chat');
                    handleSendMessage('Inquire about Nortval loan options and private wealth line of credit.');
                  }}
                  className="p-3 text-left rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-slate-600 transition-all flex items-start gap-2.5 group"
                >
                  <Sparkles className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-medium text-slate-200 group-hover:text-emerald-400 transition-colors">
                      Loan Features Inquiry
                    </div>
                    <div className="text-slate-400 text-[11px]">
                      Personal & commercial credit structuring
                    </div>
                  </div>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('chat');
                    handleSendMessage('I forgot my login password or 4-digit security PIN for harriet020.');
                  }}
                  className="p-3 text-left rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-slate-600 transition-all flex items-start gap-2.5 group"
                >
                  <HelpCircle className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-medium text-slate-200 group-hover:text-emerald-400 transition-colors">
                      Credentials & Security Reset
                    </div>
                    <div className="text-slate-400 text-[11px]">
                      Username, password or PIN recovery
                    </div>
                  </div>
                </button>
              </div>
            </div>

            {/* Security Guarantee */}
            <div className="p-3.5 bg-slate-950/60 rounded-xl border border-slate-800 text-[11px] text-slate-400 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Average SMS response time: <strong>under 2 minutes</strong></span>
              </div>
              <span className="text-slate-500 font-mono">256-Bit Encrypted Protocol</span>
            </div>
          </div>
        ) : (
          /* Live Chat View */
          <div className="flex flex-col flex-1 h-[420px] overflow-hidden bg-slate-950/40">
            <div className="flex-1 p-4 overflow-y-auto space-y-3">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex flex-col ${
                    msg.sender === 'user'
                      ? 'items-end'
                      : msg.sender === 'system'
                      ? 'items-center'
                      : 'items-start'
                  }`}
                >
                  {msg.sender === 'system' ? (
                    <div className="px-3 py-1 rounded-full bg-slate-800 text-slate-400 text-[11px] font-mono my-1 border border-slate-700/50">
                      {msg.text}
                    </div>
                  ) : (
                    <div
                      className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-xs leading-relaxed shadow-sm ${
                        msg.sender === 'user'
                          ? 'bg-emerald-600 text-white rounded-br-xs'
                          : 'bg-slate-800 border border-slate-700/80 text-slate-200 rounded-bl-xs'
                      }`}
                    >
                      {msg.sender === 'agent' && (
                        <div className="text-[10px] text-emerald-400 font-semibold mb-1 flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3" />
                          <span>Officer Marcus Reed (Nortval Concierge)</span>
                        </div>
                      )}
                      <p>{msg.text}</p>
                      <div
                        className={`text-[9px] mt-1 text-right ${
                          msg.sender === 'user' ? 'text-emerald-200' : 'text-slate-400'
                        }`}
                      >
                        {msg.time}
                      </div>
                    </div>
                  )}
                </div>
              ))}

              {isTyping && (
                <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-800/80 border border-slate-700/60 rounded-xl px-3 py-2 w-max">
                  <div className="flex gap-1 items-center">
                    <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce"></span>
                    <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce delay-150"></span>
                    <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce delay-300"></span>
                  </div>
                  <span className="text-[11px]">Nortval Support Officer is typing...</span>
                </div>
              )}
              <div ref={chatBottomRef} />
            </div>

            {/* Quick SMS Escalate Banner */}
            <div className="bg-slate-900 border-t border-slate-800 px-4 py-2 flex items-center justify-between text-xs">
              <span className="text-slate-400 text-[11px]">
                Prefer instant SMS? Contact <strong>{BANK_CONFIG.customerServicePhone}</strong>
              </span>
              <a
                href={smsUrl}
                className="text-emerald-400 hover:text-emerald-300 font-medium text-[11px] flex items-center gap-1 hover:underline"
              >
                Launch SMS <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            {/* Chat Input */}
            <div className="p-3 bg-slate-900 border-t border-slate-800 flex gap-2">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Type your message or inquiry here..."
                className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
              />
              <button
                onClick={() => handleSendMessage()}
                disabled={!inputMessage.trim()}
                className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:hover:bg-emerald-600 text-white px-4 py-2.5 rounded-xl font-medium text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-emerald-950"
              >
                <span>Send</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="bg-slate-950 p-3.5 border-t border-slate-800/80 text-center text-[11px] text-slate-500 flex flex-wrap items-center justify-between gap-2 px-5">
          <span>Nortval Bank & Trust • Member FDIC #{BANK_CONFIG.fdicCertificate}</span>
          <span className="text-slate-400">SMS Hotline: <strong className="text-emerald-400 font-mono">{BANK_CONFIG.customerServicePhone}</strong></span>
        </div>
      </div>
    </div>
  );
};
