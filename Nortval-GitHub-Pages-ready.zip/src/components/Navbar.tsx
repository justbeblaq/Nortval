import React, { useState } from 'react';
import { 
  Landmark, Lock, Unlock, Phone, 
  LogOut, Code2, Globe, Menu, X, ChevronDown, Sparkles
} from 'lucide-react';
import { useBank } from '../context/BankContext';
import { BANK_CONFIG, SUPPORTED_CURRENCIES } from '../config/bankConfig';

interface NavbarProps {
  onOpenConfigModal: () => void;
  onOpenTransferModal: () => void;
  onNavigate: (tab: string) => void;
  activeTab: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenConfigModal,
  onOpenTransferModal,
  onNavigate,
  activeTab,
}) => {
  const { 
    user, 
    logout, 
    isFrozen, 
    toggleAccountFreeze, 
    currency, 
    setCurrency, 
    openCustomerService,
    openLoanModal,
  } = useBank();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currencyDropdownOpen, setCurrencyDropdownOpen] = useState(false);

  return (
    <header className="sticky top-0 z-30 bg-slate-900/95 border-b border-slate-800/80 backdrop-blur-md text-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18">
          {/* Logo & Institution Branding */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate('dashboard')}>
            <div className="relative flex items-center justify-center w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-br from-emerald-500/20 via-slate-800 to-slate-900 border border-emerald-500/40 text-emerald-400 shadow-md">
              <Landmark className="w-5 h-5 sm:w-6 sm:h-6" />
              <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-slate-900 flex items-center justify-center text-[7px] font-bold text-slate-950">
                ✓
              </span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg sm:text-xl font-bold tracking-tight text-white font-serif">
                  NORTVAL
                </span>
                <span className="text-[10px] font-semibold uppercase tracking-widest text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                  Private Bank
                </span>
              </div>
              <p className="text-[10px] text-slate-400 tracking-wider">
                EST. {BANK_CONFIG.establishedYear} • FDIC INSURED
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 text-xs font-medium">
            <button
              onClick={() => onNavigate('dashboard')}
              className={`px-3 py-2 rounded-lg transition-colors ${
                activeTab === 'dashboard'
                  ? 'bg-slate-800 text-emerald-400 font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              Accounts
            </button>
            <button
              onClick={onOpenTransferModal}
              className="px-3 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors flex items-center gap-1"
            >
              <span>Transfer & Wire</span>
              <Sparkles className="w-3 h-3 text-emerald-400" />
            </button>
            <button
              onClick={() => onNavigate('transactions')}
              className={`px-3 py-2 rounded-lg transition-colors ${
                activeTab === 'transactions'
                  ? 'bg-slate-800 text-emerald-400 font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              Transactions
            </button>
            <button
              onClick={() => onNavigate('cards')}
              className={`px-3 py-2 rounded-lg transition-colors ${
                activeTab === 'cards'
                  ? 'bg-slate-800 text-emerald-400 font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              Cards
            </button>
            <button
              onClick={openLoanModal}
              className="px-3 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors"
            >
              Loans
            </button>
            <button
              onClick={() => onNavigate('settings')}
              className={`px-3 py-2 rounded-lg transition-colors ${
                activeTab === 'settings'
                  ? 'bg-slate-800 text-emerald-400 font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              Profile & Settings
            </button>
          </nav>

          {/* Right Action Controls */}
          <div className="hidden lg:flex items-center gap-2.5">
            {/* Account Status Indicator / Toggle */}
            <button
              onClick={() => toggleAccountFreeze()}
              title="Click to toggle account freeze status"
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition-all ${
                isFrozen
                  ? 'bg-amber-950/60 border-amber-500/60 text-amber-300 hover:bg-amber-900/60'
                  : 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/40'
              }`}
            >
              {isFrozen ? (
                <>
                  <Lock className="w-3.5 h-3.5 text-amber-400" />
                  <span>FROZEN</span>
                </>
              ) : (
                <>
                  <Unlock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>ACTIVE</span>
                </>
              )}
            </button>

            {/* Currency Selector Dropdown */}
            <div className="relative">
              <button
                onClick={() => setCurrencyDropdownOpen(!currencyDropdownOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700 text-xs text-slate-200 hover:bg-slate-800 transition-colors"
              >
                <Globe className="w-3.5 h-3.5 text-slate-400" />
                <span className="font-mono font-semibold">{currency}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {currencyDropdownOpen && (
                <div className="absolute right-0 mt-1.5 w-44 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl py-1 z-50">
                  <div className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-slate-400 border-b border-slate-800">
                    Display Currency
                  </div>
                  {Object.values(SUPPORTED_CURRENCIES).map((c) => (
                    <button
                      key={c.code}
                      onClick={() => {
                        setCurrency(c.code);
                        setCurrencyDropdownOpen(false);
                      }}
                      className={`w-full px-3 py-2 text-left text-xs flex items-center justify-between hover:bg-slate-800 transition-colors ${
                        currency === c.code ? 'text-emerald-400 font-semibold bg-slate-800/40' : 'text-slate-300'
                      }`}
                    >
                      <span>{c.name}</span>
                      <span className="font-mono text-slate-400">{c.symbol}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Support / SMS Trigger */}
            <button
              onClick={() => openCustomerService('Header Concierge Request')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md shadow-emerald-950 transition-all hover:scale-[1.02]"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>SMS Concierge</span>
            </button>

            {/* Code / Config Guide */}
            <button
              onClick={onOpenConfigModal}
              title="View & Edit Code Config Guide"
              className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-indigo-300 hover:text-indigo-200 transition-colors"
            >
              <Code2 className="w-4 h-4" />
            </button>

            {/* User Profile Pill */}
            <button
              onClick={() => onNavigate('settings')}
              className="flex items-center gap-2 pl-2 pr-3 py-1 rounded-xl bg-slate-800/80 border border-slate-700/80 hover:border-slate-600 text-xs text-slate-200 transition-colors"
            >
              <img
                src={user.avatarUrl}
                alt={user.name}
                className="w-6 h-6 rounded-full object-cover border border-emerald-500/40"
              />
              <span className="font-medium text-slate-200 truncate max-w-[100px]">
                {user.name.split(' ')[0]}
              </span>
            </button>

            {/* Logout */}
            <button
              onClick={logout}
              title="Sign Out of Secure Session"
              className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-slate-800 transition-colors"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              onClick={() => openCustomerService()}
              className="p-2 rounded-lg bg-emerald-600 text-white text-xs flex items-center justify-center"
            >
              <Phone className="w-4 h-4" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-300 hover:text-white rounded-lg hover:bg-slate-800"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-800 py-3 space-y-2 text-xs">
            <div className="flex items-center justify-between px-2 pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <img
                  src={user.avatarUrl}
                  alt={user.name}
                  className="w-8 h-8 rounded-full object-cover"
                />
                <div>
                  <div className="font-semibold text-white">{user.name}</div>
                  <div className="text-[10px] text-slate-400">@{user.username}</div>
                </div>
              </div>
              <button
                onClick={() => toggleAccountFreeze()}
                className={`px-2 py-1 rounded text-[10px] font-bold ${
                  isFrozen ? 'bg-amber-900/60 text-amber-300' : 'bg-emerald-900/60 text-emerald-300'
                }`}
              >
                {isFrozen ? 'FROZEN' : 'ACTIVE'}
              </button>
            </div>

            <div className="grid grid-cols-2 gap-1 pt-1">
              <button
                onClick={() => { onNavigate('dashboard'); setMobileMenuOpen(false); }}
                className="p-2 text-left rounded-lg hover:bg-slate-800 text-slate-200"
              >
                Accounts Overview
              </button>
              <button
                onClick={() => { onOpenTransferModal(); setMobileMenuOpen(false); }}
                className="p-2 text-left rounded-lg hover:bg-slate-800 text-emerald-400 font-semibold"
              >
                + Transfer & Wire
              </button>
              <button
                onClick={() => { onNavigate('transactions'); setMobileMenuOpen(false); }}
                className="p-2 text-left rounded-lg hover:bg-slate-800 text-slate-200"
              >
                Transactions
              </button>
              <button
                onClick={() => { onNavigate('cards'); setMobileMenuOpen(false); }}
                className="p-2 text-left rounded-lg hover:bg-slate-800 text-slate-200"
              >
                Debit Cards
              </button>
              <button
                onClick={() => { openLoanModal(); setMobileMenuOpen(false); }}
                className="p-2 text-left rounded-lg hover:bg-slate-800 text-slate-200"
              >
                Loans & Credit
              </button>
              <button
                onClick={() => { onNavigate('settings'); setMobileMenuOpen(false); }}
                className="p-2 text-left rounded-lg hover:bg-slate-800 text-slate-200"
              >
                Profile & Settings
              </button>
            </div>

            <div className="pt-2 border-t border-slate-800 flex items-center justify-between px-2">
              <button
                onClick={() => { onOpenConfigModal(); setMobileMenuOpen(false); }}
                className="text-indigo-400 hover:underline flex items-center gap-1"
              >
                <Code2 className="w-3.5 h-3.5" />
                <span>Code Config Guide</span>
              </button>

              <button
                onClick={logout}
                className="text-red-400 hover:underline flex items-center gap-1"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
