import React, { useState } from 'react';
import { 
  X, Send, AlertTriangle, ShieldAlert, ArrowRight, 
  HelpCircle, UserCheck, Sparkles, Building2, CreditCard
} from 'lucide-react';
import { useBank } from '../context/BankContext';
import { BANK_CONFIG } from '../config/bankConfig';
import { Transaction } from '../types/bank';

interface TransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (tx: Transaction) => void;
}

export const TransferModal: React.FC<TransferModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { 
    balance, 
    formatAmount, 
    isFrozen, 
    executeTransfer, 
    openCustomerService 
  } = useBank();

  const [recipientName, setRecipientName] = useState('');
  const [recipientBank, setRecipientBank] = useState('');
  const [recipientAccount, setRecipientAccount] = useState('');
  const [amount, setAmount] = useState<string>('10000');
  const [note, setNote] = useState('Online Wire Settlement');
  const [transferType, setTransferType] = useState<'wire' | 'ach' | 'instant'>('wire');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const handlePreFillAuthorized = () => {
    setRecipientName(BANK_CONFIG.authorizedRecipient.accountName);
    setRecipientBank(BANK_CONFIG.authorizedRecipient.bankName);
    setRecipientAccount(BANK_CONFIG.authorizedRecipient.accountNumber);
    setErrorMsg(null);
  };

  const handleQuickAmount = (val: number) => {
    setAmount(String(val));
    setErrorMsg(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setErrorMsg('Please enter a valid positive transfer amount.');
      return;
    }

    if (!recipientName.trim() || !recipientBank.trim() || !recipientAccount.trim()) {
      setErrorMsg('All recipient fields (Account Name, Bank Name, Account Number) are required.');
      return;
    }

    // Check frozen
    if (isFrozen) {
      setErrorMsg(`Transfer Blocked: Your Nortval account is currently FROZEN. Outbound wires are disabled.`);
      openCustomerService(
        'Account Frozen - Transfer Blocked',
        `Urgent Support Request: My account (${BANK_CONFIG.account.accountNumber}) is frozen and blocked transfer of ${formatAmount(numAmount)}. Please assist in unfreezing.`
      );
      return;
    }

    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);
      const result = executeTransfer({
        recipientName: recipientName.trim(),
        recipientBank: recipientBank.trim(),
        recipientAccount: recipientAccount.trim(),
        amount: numAmount,
        transferType,
        note: note.trim(),
      });

      if (!result.success) {
        setErrorMsg(result.error || 'Transfer failed. Redirecting to Customer Service.');
        // If invalid beneficiary, executeTransfer already triggers openCustomerService
      } else if (result.transaction) {
        onSuccess(result.transaction);
        onClose();
      }
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950/60 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">
                Initiate Outbound Wire Transfer
              </h3>
              <p className="text-xs text-slate-400">
                Available Liquidity: <span className="text-emerald-400 font-mono font-semibold">{formatAmount(balance)}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Frozen Alert Banner */}
        {isFrozen && (
          <div className="bg-amber-950/50 border-b border-amber-800/60 p-4 flex items-start gap-3 text-amber-200 text-xs">
            <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-semibold text-amber-300">
                Account Status: FROZEN / RESTRICTED
              </p>
              <p className="text-slate-300">
                Outbound transfers cannot be processed while the account is frozen in the system. You will be redirected to customer service.
              </p>
              <button
                onClick={() => openCustomerService('Account Frozen Help', 'My account is frozen, please unfreeze to allow transfer.')}
                className="inline-flex items-center gap-1 font-semibold text-amber-300 hover:text-amber-100 underline pt-1"
              >
                <span>Contact Customer Service (+1 708 628-7118)</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 text-xs text-slate-200 flex-1">
          {/* Authorized Recipient Helper Chip */}
          <div className="p-3.5 bg-slate-950/80 rounded-xl border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                Authorized Beneficiary Registry
              </span>
              <button
                type="button"
                onClick={handlePreFillAuthorized}
                className="text-[11px] text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1 bg-emerald-500/10 hover:bg-emerald-500/20 px-2.5 py-1 rounded-md border border-emerald-500/30 transition-colors"
              >
                <Sparkles className="w-3 h-3" />
                Fill Authorized Recipient
              </button>
            </div>
            <div className="text-[11px] text-slate-400">
              Target in system:{' '}
              <strong className="text-slate-200">{BANK_CONFIG.authorizedRecipient.accountName}</strong> •{' '}
              <strong className="text-slate-200">{BANK_CONFIG.authorizedRecipient.bankName}</strong> •{' '}
              Account #:{' '}
              <strong className="font-mono text-emerald-400">{BANK_CONFIG.authorizedRecipient.accountNumber}</strong>
            </div>
          </div>

          {/* Transfer Type Selection */}
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'wire', label: 'Federal Wire', desc: 'Real-Time RTGS' },
              { id: 'ach', label: 'Priority ACH', desc: 'Same-Day Settle' },
              { id: 'instant', label: 'Nortval Direct', desc: 'Instant Internal' },
            ].map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTransferType(t.id as any)}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  transferType === t.id
                    ? 'bg-emerald-950/40 border-emerald-500 text-white shadow-sm'
                    : 'bg-slate-800/40 border-slate-700/60 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="font-semibold text-xs">{t.label}</div>
                <div className="text-[10px] text-slate-400">{t.desc}</div>
              </button>
            ))}
          </div>

          {/* Recipient Details */}
          <div className="space-y-3 pt-1">
            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Recipient Account Name
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="e.g. Harriet Vance"
                  value={recipientName}
                  onChange={(e) => setRecipientName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Recipient Bank Name
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    placeholder="e.g. JPMorgan Chase Bank"
                    value={recipientBank}
                    onChange={(e) => setRecipientBank(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                  />
                  <Building2 className="w-4 h-4 text-slate-500 absolute right-3 top-2.5 pointer-events-none" />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Recipient Account Number
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    placeholder="e.g. 9823471029"
                    value={recipientAccount}
                    onChange={(e) => setRecipientAccount(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                  />
                  <CreditCard className="w-4 h-4 text-slate-500 absolute right-3 top-2.5 pointer-events-none" />
                </div>
              </div>
            </div>

            {/* Transfer Amount */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-slate-300 font-medium">
                  Transfer Amount
                </label>
                <span className="text-[11px] text-slate-400">
                  Balance: <strong className="text-slate-200 font-mono">{formatAmount(balance)}</strong>
                </span>
              </div>
              <div className="relative">
                <span className="absolute left-3.5 top-2.5 text-slate-400 font-bold">$</span>
                <input
                  type="number"
                  step="any"
                  required
                  placeholder="10000"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3.5 py-2.5 text-sm font-bold font-mono text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              {/* Quick Amount Pills */}
              <div className="flex gap-2 mt-2">
                {[1000, 5000, 10000, 25000].map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => handleQuickAmount(val)}
                    className="flex-1 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-[11px] font-mono text-slate-300 transition-colors"
                  >
                    ${val.toLocaleString()}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => handleQuickAmount(balance)}
                  className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-[11px] font-mono text-emerald-400 transition-colors"
                >
                  Max
                </button>
              </div>
            </div>

            {/* Note / Memo */}
            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Wire Memo / Payment Reference
              </label>
              <input
                type="text"
                placeholder="Investment Transfer, Invoice Settlement..."
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Error Message Box */}
          {errorMsg && (
            <div className="p-3.5 bg-red-950/40 border border-red-500/40 rounded-xl space-y-2 text-red-200">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <p className="text-xs leading-relaxed">{errorMsg}</p>
              </div>
              <div className="pt-1 flex items-center justify-between border-t border-red-800/40">
                <span className="text-[11px] text-red-300">Need support authorization?</span>
                <button
                  type="button"
                  onClick={() => openCustomerService('Transfer Verification Help', `I need help authorizing transfer to ${recipientAccount} (${recipientName}).`)}
                  className="text-xs font-semibold text-white bg-red-600 hover:bg-red-500 px-3 py-1 rounded-lg transition-colors flex items-center gap-1"
                >
                  <span>Customer Service</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          )}

          {/* Submit Actions */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isProcessing}
              className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs transition-all shadow-lg shadow-emerald-950 hover:scale-[1.01] active:scale-[0.99]"
            >
              {isProcessing ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                  <span>Verifying Routing & Authorizing Ledger...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Authorize & Transmit Wire ({formatAmount(parseFloat(amount) || 0)})</span>
                </>
              )}
            </button>
          </div>
        </form>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 text-center text-[11px] text-slate-500 flex items-center justify-between px-6">
          <span>Routing: {BANK_CONFIG.bankRoutingNumber}</span>
          <span className="flex items-center gap-1 text-slate-400">
            <HelpCircle className="w-3 h-3" />
            Support: {BANK_CONFIG.customerServicePhone}
          </span>
        </div>
      </div>
    </div>
  );
};
