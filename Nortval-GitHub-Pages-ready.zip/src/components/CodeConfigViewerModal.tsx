import React, { useState } from 'react';
import { 
  X, Code2, Lock, Unlock, RefreshCw, 
  Check, Copy, Phone, UserCheck, Shield 
} from 'lucide-react';
import { useBank } from '../context/BankContext';
import { BANK_CONFIG, SUPPORTED_CURRENCIES } from '../config/bankConfig';

interface CodeConfigViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CodeConfigViewerModal: React.FC<CodeConfigViewerModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { 
    balance, 
    setAccountBalance, 
    isFrozen, 
    toggleAccountFreeze, 
    currency, 
    setCurrency, 
    resetToDefaultConfig, 
    user 
  } = useBank();

  const [customBalanceInput, setCustomBalanceInput] = useState(String(balance));
  const [copiedCode, setCopiedCode] = useState(false);

  if (!isOpen) return null;

  const handleApplyBalance = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(customBalanceInput);
    if (!isNaN(val) && val >= 0) {
      setAccountBalance(val);
    }
  };

  const sampleCodeSnippet = `// Location: src/config/bankConfig.ts

export const BANK_CONFIG = {
  // Credentials
  auth: {
    username: "${user.username}",
    password: "${BANK_CONFIG.auth.password}",
    pin: "${BANK_CONFIG.auth.pin}",
  },

  // Account State
  account: {
    initialBalance: ${balance}, // Edit balance here
    defaultCurrency: "${currency}", // 'USD', 'EUR', 'GBP', etc.
    isFrozen: ${isFrozen}, // true = locked, false = active
  },

  // Only money sent to this account is accepted:
  authorizedRecipient: {
    accountNumber: "${BANK_CONFIG.authorizedRecipient.accountNumber}",
    accountName: "${BANK_CONFIG.authorizedRecipient.accountName}",
    bankName: "${BANK_CONFIG.authorizedRecipient.bankName}",
  },

  // Customer Service SMS Hotline
  customerServicePhone: "${BANK_CONFIG.customerServicePhone}",
};`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(sampleCodeSnippet);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950/60 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Code2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">
                Code & Frontend Configuration Center
              </h3>
              <p className="text-xs text-slate-400">
                File: <code className="text-indigo-300 font-mono">src/config/bankConfig.ts</code>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-slate-200 flex-1">
          {/* Quick Interactive Toggles (Live In-App Testing) */}
          <div className="space-y-3 bg-slate-950/70 p-4 rounded-xl border border-slate-800">
            <h4 className="font-semibold text-white text-sm flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400" />
              Live Interactive Controls (Test Instantly)
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              {/* Change Balance Input */}
              <form onSubmit={handleApplyBalance} className="space-y-1.5">
                <label className="text-slate-300 font-medium flex items-center justify-between">
                  <span>Edit Account Balance:</span>
                  <span className="text-emerald-400 font-mono font-bold">${balance.toLocaleString()}</span>
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <span className="absolute left-2.5 top-2 text-slate-500 font-bold">$</span>
                    <input
                      type="number"
                      step="any"
                      value={customBalanceInput}
                      onChange={(e) => setCustomBalanceInput(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-6 pr-2 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                  <button
                    type="submit"
                    className="bg-indigo-600 hover:bg-indigo-500 text-white font-medium px-3 py-1.5 rounded-lg transition-colors"
                  >
                    Apply
                  </button>
                </div>
              </form>

              {/* Currency Selector */}
              <div className="space-y-1.5">
                <label className="text-slate-300 font-medium">
                  Active Currency ({currency}):
                </label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  {Object.values(SUPPORTED_CURRENCIES).map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.name} ({c.symbol})
                    </option>
                  ))}
                </select>
              </div>

              {/* Freeze Toggle */}
              <div className="space-y-1.5">
                <label className="text-slate-300 font-medium">
                  Account Freeze Status:
                </label>
                <button
                  type="button"
                  onClick={() => toggleAccountFreeze()}
                  className={`w-full py-2 px-3 rounded-lg border flex items-center justify-center gap-2 font-medium transition-all ${
                    isFrozen
                      ? 'bg-amber-950/60 border-amber-500/60 text-amber-300 hover:bg-amber-900/60'
                      : 'bg-emerald-950/60 border-emerald-500/60 text-emerald-300 hover:bg-emerald-900/60'
                  }`}
                >
                  {isFrozen ? (
                    <>
                      <Lock className="w-3.5 h-3.5" />
                      <span>FROZEN (Transfers Blocked) - Click to Unfreeze</span>
                    </>
                  ) : (
                    <>
                      <Unlock className="w-3.5 h-3.5" />
                      <span>ACTIVE (Normal) - Click to Freeze Account</span>
                    </>
                  )}
                </button>
              </div>

              {/* Reset to Code Defaults */}
              <div className="space-y-1.5 flex flex-col justify-end">
                <button
                  type="button"
                  onClick={resetToDefaultConfig}
                  className="w-full py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 flex items-center justify-center gap-2 font-medium transition-colors"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
                  <span>Reset All to Code Defaults</span>
                </button>
              </div>
            </div>
          </div>

          {/* Config Explanation & Code Block */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-300 text-xs">
                Code Customization Reference:
              </span>
              <button
                onClick={handleCopyCode}
                className="text-[11px] text-indigo-400 hover:text-indigo-300 flex items-center gap-1 bg-indigo-500/10 px-2.5 py-1 rounded-md border border-indigo-500/20"
              >
                {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copiedCode ? 'Copied' : 'Copy Snippet'}</span>
              </button>
            </div>

            <pre className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-[11px] font-mono text-indigo-200 overflow-x-auto leading-relaxed">
              <code>{sampleCodeSnippet}</code>
            </pre>
          </div>

          {/* Summary of Hardcoded values */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
            <div className="p-3 bg-slate-800/40 border border-slate-700/60 rounded-xl space-y-1">
              <div className="text-slate-400 font-semibold flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                Configured Login Credentials:
              </div>
              <div className="text-slate-300 font-mono">
                User: <span className="text-emerald-400">{BANK_CONFIG.auth.username}</span> | Pass: <span className="text-emerald-400">{BANK_CONFIG.auth.password}</span> | PIN: <span className="text-emerald-400">{BANK_CONFIG.auth.pin}</span>
              </div>
            </div>

            <div className="p-3 bg-slate-800/40 border border-slate-700/60 rounded-xl space-y-1">
              <div className="text-slate-400 font-semibold flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                Customer Support SMS:
              </div>
              <div className="text-slate-300 font-mono">
                SMS Line: <span className="text-emerald-400">{BANK_CONFIG.customerServicePhone}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 bg-slate-950 border-t border-slate-800 flex justify-end px-6">
          <button
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-700 text-white font-medium px-4 py-2 rounded-xl text-xs transition-colors"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
