import React from 'react';
import { MessageSquare, Phone } from 'lucide-react';
import { useBank } from '../context/BankContext';
import { BANK_CONFIG } from '../config/bankConfig';

export const CustomerServiceFloat: React.FC = () => {
  const { openCustomerService } = useBank();

  return (
    <div className="fixed bottom-5 right-5 z-40 flex items-center gap-2 group">
      {/* Floating Info Pill */}
      <div 
        onClick={() => openCustomerService('General Client Assistance')}
        className="hidden md:flex items-center gap-2 bg-slate-900/90 hover:bg-slate-900 border border-slate-700/80 text-slate-200 px-3.5 py-2 rounded-full shadow-2xl backdrop-blur-md cursor-pointer transition-all hover:border-emerald-500/50 hover:scale-[1.02]"
      >
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
        <div className="text-xs">
          <span className="font-semibold text-white">24/7 Support:</span>{' '}
          <span className="text-emerald-400 font-mono">{BANK_CONFIG.customerServicePhone}</span>
        </div>
      </div>

      {/* Main Trigger Button */}
      <button
        onClick={() => openCustomerService('General Client Assistance')}
        className="relative flex items-center justify-center w-13 h-13 rounded-full bg-gradient-to-tr from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white shadow-xl shadow-emerald-950/60 border border-emerald-400/40 transition-all duration-300 hover:scale-110 active:scale-95 group focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-offset-2 focus:ring-offset-slate-900"
        title={`Contact Customer Service (${BANK_CONFIG.customerServicePhone})`}
        aria-label="Open 24/7 Customer Support and SMS"
      >
        <MessageSquare className="w-6 h-6 transition-transform group-hover:scale-110" />
        <span className="absolute -top-1 -right-1 flex h-4 w-4">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-400 items-center justify-center text-[9px] font-bold text-slate-950">
            <Phone className="w-2.5 h-2.5" />
          </span>
        </span>
      </button>
    </div>
  );
};
